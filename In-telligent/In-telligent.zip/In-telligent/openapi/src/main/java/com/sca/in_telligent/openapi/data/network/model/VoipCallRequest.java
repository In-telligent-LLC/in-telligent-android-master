package com.sca.in_telligent.openapi.data.network.model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class VoipCallRequest implements Serializable {

  @SerializedName("conferenceId")
  private String conferenceId;

  @SerializedName("senderId")
  private int senderId;

  @SerializedName("buildingId")
  private String buildingId;

  public void setConferenceId(String conferenceId) {
    this.conferenceId = conferenceId;
  }

  public void setSenderId(int senderId) {
    this.senderId = senderId;
  }

  public void setBuildingId(String buildingId) {
    this.buildingId = buildingId;
  }


}
