package com.sca.in_telligent.openapi.util;

public interface FlashHelper {

  void startFlashTask();

  void stopFlashTask();
}
