package com.sca.in_telligent.openapi;

/**
 * Created by zacharyzeno on 3/15/18.
 */

public interface BooleanCallback {

    void callback(boolean result);

}
