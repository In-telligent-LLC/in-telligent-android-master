package com.sca.in_telligent.openapi.data.network.model;

import java.io.Serializable;

public class Interest implements Serializable {

}
