package com.sca.in_telligent.openapi.data.network;


public interface ApiInterceptor {


}
