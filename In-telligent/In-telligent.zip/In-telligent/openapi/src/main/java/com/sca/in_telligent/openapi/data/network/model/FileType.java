package com.sca.in_telligent.openapi.data.network.model;

public enum FileType {

    IMAGE,
    VIDEO

}
