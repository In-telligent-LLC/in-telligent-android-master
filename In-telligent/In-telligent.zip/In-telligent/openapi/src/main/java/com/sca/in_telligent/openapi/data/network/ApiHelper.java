package com.sca.in_telligent.openapi.data.network;

import com.sca.in_telligent.openapi.data.network.model.AdResponse;
import com.sca.in_telligent.openapi.data.network.model.AlertDeleteRequest;
import com.sca.in_telligent.openapi.data.network.model.AlertOpenedRequest;
import com.sca.in_telligent.openapi.data.network.model.AlertSubscriptionRequest;
import com.sca.in_telligent.openapi.data.network.model.AutoSubscribeRequest;
import com.sca.in_telligent.openapi.data.network.model.BeaconsResponse;
import com.sca.in_telligent.openapi.data.network.model.BuildingMember;
import com.sca.in_telligent.openapi.data.network.model.CallDetailResponse;
import com.sca.in_telligent.openapi.data.network.model.CheckEmailResponse;
import com.sca.in_telligent.openapi.data.network.model.CommunityResponse;
import com.sca.in_telligent.openapi.data.network.model.CreateEditGroupRequest;
import com.sca.in_telligent.openapi.data.network.model.CreateNotificationRequest;
import com.sca.in_telligent.openapi.data.network.model.DeliveryInfoResponse;
import com.sca.in_telligent.openapi.data.network.model.EditCommunityInviteeRequest;
import com.sca.in_telligent.openapi.data.network.model.EditSaveMessageRequest;
import com.sca.in_telligent.openapi.data.network.model.FacebookLoginRequest;
import com.sca.in_telligent.openapi.data.network.model.ForgotPasswordRequest;
import com.sca.in_telligent.openapi.data.network.model.GoogleLoginRequest;
import com.sca.in_telligent.openapi.data.network.model.IntelligentGeofenceResponse;
import com.sca.in_telligent.openapi.data.network.model.InviteOthersRequest;
import com.sca.in_telligent.openapi.data.network.model.InviteeResponse;
import com.sca.in_telligent.openapi.data.network.model.LocationModel;
import com.sca.in_telligent.openapi.data.network.model.LoginRequest;
import com.sca.in_telligent.openapi.data.network.model.LoginResponse;
import com.sca.in_telligent.openapi.data.network.model.NotificationLanguageResponse;
import com.sca.in_telligent.openapi.data.network.model.NotificationResponse;
import com.sca.in_telligent.openapi.data.network.model.NotificationsResponse;
import com.sca.in_telligent.openapi.data.network.model.PushTokenRequest;
import com.sca.in_telligent.openapi.data.network.model.PushTokenSuccessResponse;
import com.sca.in_telligent.openapi.data.network.model.ResetPasswordRequest;
import com.sca.in_telligent.openapi.data.network.model.SearchCommunityResponse;
import com.sca.in_telligent.openapi.data.network.model.SignUpRequest;
import com.sca.in_telligent.openapi.data.network.model.SingleNotificationResponse;
import com.sca.in_telligent.openapi.data.network.model.SubscribeToCommunityRequest;
import com.sca.in_telligent.openapi.data.network.model.SubscriberResponse;
import com.sca.in_telligent.openapi.data.network.model.SuccessResponse;
import com.sca.in_telligent.openapi.data.network.model.SuggestNotificationRequest;
import com.sca.in_telligent.openapi.data.network.model.SupportRequest;
import com.sca.in_telligent.openapi.data.network.model.TranslationResponse;
import com.sca.in_telligent.openapi.data.network.model.UpdateSubscriberRequest;
import com.sca.in_telligent.openapi.data.network.model.UpdateSubscriptionRequest;
import com.sca.in_telligent.openapi.data.network.model.VoipCallRequest;
import com.sca.in_telligent.openapi.data.network.model.VoipCallResponse;
import com.sca.in_telligent.openapi.data.network.model.VoipTokenResponse;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import io.reactivex.Observable;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ApiHelper {

    ApiHeader getApiHeader();

    @POST(ApiEndPoint.LOGIN_WITH_PASSWORD)
    Observable<LoginResponse> loginWithPassword(@Body LoginRequest loginRequest);

    @POST(ApiEndPoint.SIGN_UP)
    Observable<LoginResponse> signUp(@Body SignUpRequest signUpRequest);

    @POST(ApiEndPoint.CHECK_EMAIL)
    Observable<CheckEmailResponse> checkEmail(@Query("email") String email);

    @POST(ApiEndPoint.FACEBOOK_LOGIN)
    Observable<LoginResponse> loginFacebook(@Body FacebookLoginRequest facebookLoginRequest);

    @POST(ApiEndPoint.GOOGLE_LOGIN)
    Observable<LoginResponse> loginGoogle(@Body GoogleLoginRequest googleLoginRequest);

    @POST(ApiEndPoint.RESET_PASSWORD)
    Observable<LoginResponse> resetPassword(@Body ResetPasswordRequest resetPasswordRequest);

    @POST(ApiEndPoint.FORGOT_PASSWORD)
    Observable<LoginResponse> forgotPassword(@Body ForgotPasswordRequest forgotPasswordRequest);

    @GET(ApiEndPoint.CURRENT_SUBSCRIBER)
    Observable<SubscriberResponse> getCurrentSubscriber();

    @GET(ApiEndPoint.CURRENT_SUBSCRIBER_INBOX)
    Observable<NotificationResponse> getCurrentSubscriberInbox(@Path("page") String page);

    @GET(ApiEndPoint.SAVED_MESSAGES_CURRENT)
    Observable<NotificationResponse> getSavedMessages();

    @POST(ApiEndPoint.SAVED_MESSAGES_CURRENT)
    Observable<SuccessResponse> editSavedMessage(@Body EditSaveMessageRequest editSaveMessageRequest);

    @GET(ApiEndPoint.SEARCH_COMMUNITIES)
    Observable<SearchCommunityResponse> searchCommunities(@Query("query") String query);

    @GET(ApiEndPoint.GET_NOTIFICATIONS)
    Observable<NotificationsResponse> getAllNotifications(@Path("buildingId") String buildingId);

    @GET(ApiEndPoint.GET_NOTIFICATION)
    Observable<SingleNotificationResponse> getNotification(@Path("notificationId") String notificationId);

    @GET(ApiEndPoint.LIST_LANGUAGES)
    Observable<NotificationLanguageResponse> getLanguages();

    @POST(ApiEndPoint.SYNC_ALERT_SUBSCRIPTION)
    Observable<SuccessResponse> syncAlertSubscription(
            @Body AlertSubscriptionRequest alertSubscriptionRequest);

    @Multipart
    @POST(ApiEndPoint.CREATE_UPDATE_GROUP)
    Observable<SuccessResponse> createOrEditGroup(@Path("buildingId") String buildingId,
                                                  @Part MultipartBody.Part filePart, @Part("name") RequestBody name,
                                                  @Part("description") RequestBody description);

    @POST(ApiEndPoint.CREATE_UPDATE_GROUP)
    Observable<SuccessResponse> createOrEditGroupNoThumbnail(@Path("buildingId") String buildingId,
                                                             @Body CreateEditGroupRequest createEditGroupRequest);

    @GET(ApiEndPoint.SUGGESTED_BUILDINGS)
    Observable<SearchCommunityResponse> getSuggestedGroups();

    @GET(ApiEndPoint.GET_COMMUNITY)
    Observable<CommunityResponse> getCommunity(@Path("buildingId") int buildingId);

    @POST(ApiEndPoint.UPDATE_SUBSCRIPTION)
    Observable<SuccessResponse> updateSubscription(
            @Body UpdateSubscriptionRequest updateSubscriptionRequest);

    @GET(ApiEndPoint.BUILDING_INVITEES)
    Observable<InviteeResponse> getInvitees(@Path("buildingId") String buildingId);

    @GET(ApiEndPoint.BUILDING_MEMBERS)
    Observable<ArrayList<BuildingMember>> getBuildingMembers(
            @Path(value = "buildingId", encoded = false) String buildingId);

    @GET(ApiEndPoint.DELIVERY_INFO)
    Observable<DeliveryInfoResponse> getDeliveryInformation(@Path("buildingId") String buildingId,
                                                            @Path("notificationId") String notificationId);

    @POST(ApiEndPoint.INVITE_OTHERS)
    Observable<SuccessResponse> inviteOthers(@Path("buildingId") String buildingId,
                                             @Body InviteOthersRequest inviteOthersRequest);

    @POST(ApiEndPoint.EDIT_MEMBER)
    Observable<SuccessResponse> editMember(@Path("inviteeId") int inviteeId, @Body EditCommunityInviteeRequest inviteOthersRequest);

    @POST(ApiEndPoint.REMOVE_MEMBER_FROM_COMMUNITY)
    Observable<SuccessResponse> removeMember(@Path("inviteId") int inviteId);

    @POST(ApiEndPoint.SYNC_METADA)
    Observable<SubscriberResponse> updateUser(@Body UpdateSubscriberRequest updateSubscriberRequest);

    @Multipart
    @POST(ApiEndPoint.CREATE_NOTIFICATION)
    Observable<SuccessResponse> createNotification(@Part List<MultipartBody.Part> attachments,
                                                   @Part("buildingId") RequestBody buildingId, @Part("title") RequestBody title
            , @Part("body") RequestBody body, @Part("type") RequestBody type,
                                                   @Part("subscribers") RequestBody subscribers,
                                                   @Part("send_to_email") RequestBody send_to_email);

    @Multipart
    @POST(ApiEndPoint.SUGGEST_NOTIFICATION)
    Observable<SuccessResponse> suggestNotification(@Part List<MultipartBody.Part> attachments,
                                                    @Part("building_id") RequestBody buildingId, @Part("title") RequestBody title
            , @Part("description") RequestBody body);

    @POST(ApiEndPoint.CREATE_NOTIFICATION)
    Observable<SuccessResponse> createNotificationNoThumbnail(
            @Body CreateNotificationRequest createNotificationRequest);

    @POST(ApiEndPoint.SUGGEST_NOTIFICATION)
    Observable<SuccessResponse> suggestNotificationNoThumbnail(
            @Body SuggestNotificationRequest suggestNotificationRequest);

    @POST(ApiEndPoint.REGISTER_PUSH)
    Observable<PushTokenSuccessResponse> registerPushToken(@Body PushTokenRequest pushTokenRequest);

    @GET(ApiEndPoint.SUBSCRIBER_LAST_LOCATION)
    Observable<LocationModel> getLastLocation(@Path("subscriberId") String subscriberId);

    @GET(ApiEndPoint.UPDATED_LOCATION)
    Observable<LocationModel> getUpdatedLocation(@Path("subscriberId") String subscriberId);

    @POST(ApiEndPoint.FEED_ALERT_SEND)
    Observable<String> sendWeatherAlert(@Path("weatherAlertId") String weatherAlertId,
                                        @Body LocationModel locationModel);

    @POST(ApiEndPoint.RECEIVE_MESSAGE)
    Observable<JSONObject> receivedMessage(@Path("msgId") String msgId);

    @POST(ApiEndPoint.RESPOND_TO_MESSAGE)
    Observable<JSONObject> respondToMessage(@Path("msgId") String msgId, @Body HashMap<String, Object> map);

    @POST(ApiEndPoint.ALERT_OPENED)
    Observable<SuccessResponse> alertOpened(@Body AlertOpenedRequest alertOpenedRequest);

    @POST(ApiEndPoint.ALERT_DELIVERED)
    Observable<SuccessResponse> alertDelivered(@Body AlertOpenedRequest alertDeliverRequest);

    @POST(ApiEndPoint.PERSONAL_SAFETY_RESPONSE)
    Observable<JSONObject> respondPersonalSafety(@Body HashMap<String, Object> map);

    @GET(ApiEndPoint.TRANSLATE_MESSAGE_ALERT)
    Observable<TranslationResponse> getAlertTranslation(@Path("id") String id,
                                                        @Path("lang") String lang);

    @GET(ApiEndPoint.GET_GEOFENCES)
    Observable<IntelligentGeofenceResponse> getGeofences(@Query("lat") String lat,
                                                         @Query("lng") String lng);

    @POST(ApiEndPoint.REFRESH_GEOFENCES)
    Observable<SuccessResponse> refreshGeofences(@Body LocationModel refreshGeofencesRequest);

    @POST(ApiEndPoint.VOIP_TOKEN)
    Observable<VoipTokenResponse> getVoipToken();

    @POST(ApiEndPoint.VOIP_MAKE_CALL)
    Observable<VoipCallResponse> makeVoipCall(@Body VoipCallRequest voipCallRequest);

    @POST(ApiEndPoint.VOIP_CALL_DETAILS)
    Observable<CallDetailResponse> getCallDetail(@Path("conferenceId") String conferenceId);

    @POST(ApiEndPoint.DELETE_PERSONAL_COMMUNITY)
    Observable<SuccessResponse> deletePersonalCommunity(@Path("buildingId") String buildingId);

    @POST(ApiEndPoint.DELETE_ALERT)
    Observable<SuccessResponse> deleteAlert(@Body AlertDeleteRequest alertDeleteRequest);

    @POST(ApiEndPoint.SEND_HELP_EMAIL)
    Observable<SuccessResponse> sendSupportMail(@Body SupportRequest supportRequest);

    @POST(ApiEndPoint.SUBSCRIBE_TO_COMMUNITY)
    Observable<SuccessResponse> updateSubscriptionToCommunity(@Body SubscribeToCommunityRequest subscribeToCommunityRequest);

    @POST(ApiEndPoint.AUTO_SUBSCRIBE)
    Observable<SuccessResponse> autoSubscribe(@Body AutoSubscribeRequest autoSubscribeRequest);

    @POST(ApiEndPoint.SUBSCRIBER_OPENED_APP)
    Observable<SuccessResponse> appOpened();

    @GET(ApiEndPoint.BEACONS_ALL)
    Observable<BeaconsResponse> getAllBeacons();

    @POST(ApiEndPoint.SUGGESTED_BUILDINGS_IGNORE)
    Observable<SuccessResponse> ignoreBuilding(@Path("buildingId") String buildingId);

    @GET(ApiEndPoint.AD)
    Observable<AdResponse> getAd();

    @POST(ApiEndPoint.CLICK_AD)
    Observable<SuccessResponse> clickAd(@Path("adId") int adId);

}
