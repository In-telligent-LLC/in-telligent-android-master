package com.sca.in_telligent.ui.base;

import static com.facebook.FacebookSdk.getApplicationContext;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.StringRes;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.widget.RelativeLayout;
import butterknife.Unbinder;
import com.sca.in_telligent.R;
import com.sca.in_telligent.di.component.ActivityComponent;

public abstract class BaseDialog extends DialogFragment implements DialogMvpView {

  private BaseActivity mActivity;
  private Unbinder mUnBinder;

  @Override
  public void onAttach(Context context) {
    super.onAttach(context);
    if (context instanceof BaseActivity) {
      BaseActivity mActivity = (BaseActivity) context;
      this.mActivity = mActivity;
      mActivity.onFragmentAttached();
    }
  }

  @Override
  public void showLoading() {
    if (mActivity != null) {
      mActivity.showLoading();
    }
  }

  @Override
  public void hideLoading() {
    if (mActivity != null) {
      mActivity.hideLoading();
    }
  }

  @Override
  public void onError(String message) {
    if (mActivity != null) {
      mActivity.onError(message);
    }
  }

  @Override
  public void onError(@StringRes int resId) {
    if (mActivity != null) {
      mActivity.onError(resId);
    }
  }

  @Override
  public void showMessage(String message) {
    if (mActivity != null) {
      mActivity.showMessage(message);
    }
  }

  @Override
  public void showMessage(@StringRes int resId) {
    if (mActivity != null) {
      mActivity.showMessage(resId);
    }
  }

  @Override
  public boolean isNetworkConnected() {
    if (mActivity != null) {
      return mActivity.isNetworkConnected();
    }
    return false;
  }

  @Override
  public void onDetach() {
    mActivity = null;
    super.onDetach();
  }

  @Override
  public void hideKeyboard() {
    if (mActivity != null) {
      mActivity.hideKeyboard();
    }
  }

  public BaseActivity getBaseActivity() {
    return mActivity;
  }

  public ActivityComponent getActivityComponent() {
    if (mActivity != null) {
      return mActivity.getActivityComponent();
    }
    return null;
  }

  public void setUnBinder(Unbinder unBinder) {
    mUnBinder = unBinder;
  }

  protected abstract void setUp(View view);

  @NonNull
  @Override
  public Dialog onCreateDialog(Bundle savedInstanceState) {
    // the content
    final RelativeLayout root = new RelativeLayout(getActivity());
    root.setLayoutParams(new ViewGroup.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        LayoutParams.MATCH_PARENT));

    // creating the fullscreen dialog
    final Dialog dialog = new Dialog(getContext());
//    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
    dialog.setContentView(root);
    if (dialog.getWindow() != null) {
      dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
      dialog.getWindow().setLayout(
          ViewGroup.LayoutParams.MATCH_PARENT,
          LayoutParams.MATCH_PARENT);

    }
    dialog.setCanceledOnTouchOutside(false);

    return dialog;
  }

  @Override
  public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
    super.onViewCreated(view, savedInstanceState);
    setUp(view);
  }

  public void show(FragmentManager fragmentManager, String tag) {
    FragmentTransaction transaction = fragmentManager.beginTransaction();
    Fragment prevFragment = fragmentManager.findFragmentByTag(tag);
    if (prevFragment != null) {
      transaction.remove(prevFragment);
    }
    transaction.addToBackStack(null);
    show(transaction, tag);
  }

  @Override
  public void dismissDialog(String tag) {
    dismiss();
    getBaseActivity().onFragmentDetached(tag);
  }

  @Override
  public void onDestroy() {
    if (mUnBinder != null) {
      mUnBinder.unbind();
    }
    super.onDestroy();
  }

  @Override
  public void startActivityWithDeeplink(Intent intent) {
    final Uri deepLinkUri = getActivity().getIntent().getParcelableExtra("deep_link_uri");
    if (deepLinkUri != null) {
      intent.putExtra("deep_link_uri", deepLinkUri);
    }
    startActivity(intent);
  }

  @Override
  public void showMessageSnack(String message) {

  }

  @Override
  public void showPopup(String message) {

  }

  public void showNetworkDialog() {
    AlertDialog.Builder alertDialog = new AlertDialog.Builder(mActivity);
    alertDialog.setTitle("Alert");
    alertDialog.setMessage(R.string.please_check_your_network_connection_try_again);

    alertDialog
        .setNeutralButton(getString(android.R.string.ok), new DialogInterface.OnClickListener() {
          @Override
          public void onClick(DialogInterface dialogInterface, int i) {

          }
        });

    alertDialog.show();
  }
}