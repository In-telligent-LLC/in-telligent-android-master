package com.sca.in_telligent.ui.group.member.edit;

import com.sca.in_telligent.ui.base.MvpView;

public interface EditMemberMvpView extends MvpView {

  void editResult(boolean success);
}
