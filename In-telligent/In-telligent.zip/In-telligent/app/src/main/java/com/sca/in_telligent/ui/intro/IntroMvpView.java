package com.sca.in_telligent.ui.intro;

import com.sca.in_telligent.ui.base.MvpView;

public interface IntroMvpView extends MvpView {

}
