package com.sca.in_telligent.ui.group.alert.detail;

import com.sca.in_telligent.ui.base.MvpPresenter;

public interface AlertDetailMvpPresenter<V extends AlertDetailMvpView> extends MvpPresenter<V> {

}
