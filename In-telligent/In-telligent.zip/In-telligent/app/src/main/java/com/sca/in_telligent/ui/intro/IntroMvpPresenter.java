package com.sca.in_telligent.ui.intro;

import com.sca.in_telligent.di.PerActivity;
import com.sca.in_telligent.ui.base.MvpPresenter;

@PerActivity
public interface IntroMvpPresenter<V extends IntroMvpView> extends MvpPresenter<V> {

}
