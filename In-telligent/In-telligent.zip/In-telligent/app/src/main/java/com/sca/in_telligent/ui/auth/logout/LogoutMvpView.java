package com.sca.in_telligent.ui.auth.logout;

import com.sca.in_telligent.ui.base.MvpView;

public interface LogoutMvpView extends MvpView {

  void goToLogin();
}
