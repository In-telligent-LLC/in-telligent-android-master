package com.sca.in_telligent.util;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AlertDialog;

import com.sca.in_telligent.R;

import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public final class CommonUtils {

    private static final String TAG = "CommonUtils";

    private CommonUtils() {
        // This utility class is not publicly instantiable
    }

    public static Dialog showLoadingDialog(Context context) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setView(R.layout.progress_dialog);
        Dialog dialog = builder.create();
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();

        return dialog;
//    ProgressDialog progressDialog = new ProgressDialog(context);
//    progressDialog.show();
//    if (progressDialog.getWindow() != null) {
//      progressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
//    }
//    progressDialog.setContentView(R.layout.progress_dialog);
//    progressDialog.setIndeterminate(true);
//    progressDialog.setCancelable(false);
//    progressDialog.setCanceledOnTouchOutside(false);
//    return progressDialog;
    }

    @SuppressLint("all")
    public static String getDeviceId(Context context) {
        return Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
    }

    public static Date getSilenceDate(String dateString) {
        if (dateString != null) {
            DateFormat inDf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            try {
                return inDf.parse(dateString);
            } catch (ParseException e) {
                e.printStackTrace();
                return null;
            }
        } else {
            return null;
        }
    }

    public static String getSilenceDateString(Date date) {
        DateFormat inDf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return inDf.format(date);
    }

    public static String getDateString(String oldDate) {
        DateFormat inDf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'.000Z'");
        inDf.setTimeZone(TimeZone.getTimeZone("UTC"));
        DateFormat outDf = new SimpleDateFormat("MM/dd/yy h:mm a");
        outDf.setTimeZone(TimeZone.getDefault());
        String date = null;
        try {
            Date parse = inDf.parse(oldDate);
            date = outDf.format(parse);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return date;
    }

    public static boolean isEmailValid(String email) {
        Pattern pattern;
        Matcher matcher;
        final String EMAIL_PATTERN =
                "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                        + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        pattern = Pattern.compile(EMAIL_PATTERN);
        matcher = pattern.matcher(email);
        return matcher.matches();
    }

    public static String loadJSONFromAsset(Context context, String jsonFileName)
            throws IOException {

        AssetManager manager = context.getAssets();
        InputStream is = manager.open(jsonFileName);

        int size = is.available();
        byte[] buffer = new byte[size];
        is.read(buffer);
        is.close();

        return new String(buffer, "UTF-8");
    }

    private static int[] defaultImages = new int[]{
            R.drawable.arm_at_baseball_game,
            R.drawable.blonde_girl_in_class,
            R.drawable.blonde_with_phone,
            R.drawable.business_suit_guy,
            R.drawable.closeup_phone,
            R.drawable.couple_looking_at_tablet,
            R.drawable.elevator_women,
            R.drawable.girl_in_pink_sweater,
            R.drawable.guy_glasses_and_tablet,
            R.drawable.guy_with_glasses,
            R.drawable.kid_sitting_with_backpack,
            R.drawable.lobby_guy,
            R.drawable.man_at_convention,
            R.drawable.man_leaning_on_wall,
            R.drawable.man_on_bike,
            R.drawable.man_with_glasses,
            R.drawable.sitting_with_books,
            R.drawable.two_girls_at_football_game,
            R.drawable.two_girls_looking_at_phone,
            R.drawable.woman_in_library,
            R.drawable.women_in_white_dress,
            R.drawable.women_plus_coffee_cup,
            R.drawable.women_looking_down,
            R.drawable.women_outside_on_wall,
            R.drawable.women_striped_dress,
    };

    public static int getDefaultImage(int id) {
        return defaultImages[id % defaultImages.length];
    }

    public static Map<String, String> getCountrySet() {
        String[] country = {"Afghanistan", "119"
                , "Albania", "19"
                , "Algeria", "17"
                , "American Samoa", "911"
                , "Andorra", "110"
                , "Angola", "110"
                , "Antigua & Barbuda", "911"
                , "Argentina", "101"
                , "Armenia", "103"
                , "Aruba", "911"
                , "Ascension Island", "6666"
                , "Australia", "112"
                , "Austria", "112"
                , "Azerbaijan (Baku)", "02"
                , "Bahamas", "911"
                , "Bahrain", "999"
                , "Bali", "118"
                , "Bangladesh (Dhaka)", "866 551_3"
                , "Barbados", "112"
                , "Belgium", "112"
                , "Belarus", "02"
                , "Belize", "911"
                , "Benin", "117"
                , "Bermuda", "911"
                , "Bhutan", "113"
                , "Bolivia", "911"
                , "Bonaire", "911"
                , "Bosnia_Herzegovina", "122"
                , "Botswana", "911"
                , "Brazil", "911"
                , "Bosnia", "92"
                , "British Virgin Islands", "999"
                , "Brunei", "993"
                , "Bulgaria", "166"
                , "Burkina Faso", "17"
                , "Burma/Myanmar", "999"
                , "Burundi", "117"
                , "Cambodia", "117"
                , "Cameroon", "117"
                , "Canada", "911"
                , "Canary Islands", "112"
                , "Cape Verde", "132"
                , "Cayman Islands", "911"
                , "Central African Republic", "117"
                , "Chad", "17"
                , "Chile", "133"
                , "China", "110"
                , "Colombia", "119"
                , "Comoros Islands", "17"
                , "Congo", "117"
                , "Cook Islands", "999"
                , "Costa Rica", "911"
                , "C™te d'Ivoire", "180"
                , "Croatia", "112"
                , "Cuba", "26811"
                , "Curacao", "444444"
                , "Cyprus", "112"
                , "DR Congo", "112"
                , "Denmark", "112"
                , "Djibouti", "17"
                , "Dominica", "999"
                , "Dominican Republic", "911"
                , "East Timor", "112"
                , "Easter Island", "100_244"
                , "Ecuador", "101"
                , "Egypt", "122"
                , "El Salvador", "911"
                , "England", "112"
                , "Equatorial Guinea", "113"
                , "Eritrea", "1127799"
                , "Estonia", "110"
                , "Ethiopia", "91"
                , "Falkland Islands", "999"
                , "Fiji", "911"
                , "Finland", "112"
                , "France", "112"
                , "French Guiana", "112"
                , "French Polynesia", "17"
                , "Gabon", "1730"
                , "Gambia", "17"
                , "Georgia", "022"
                , "Germany", "110"
                , "Ghana", "999"
                , "Gibraltar", "999"
                , "Greece", "112"
                , "Grenada", "911"
                , "Guadeloupe", "17"
                , "Guam", "911"
                , "Guatemala", "110"
                , "Guinea Bissau", "112"
                , "Gunea", "117"
                , "Guyana", "999"
                , "Haiti", "114"
                , "Honduras", "119"
                , "Hong Kong", "999"
                , "Hungary", "112"
                , "Iceland", "112"
                , "India", "100"
                , "Indonesia", "110"
                , "Iran", "110"
                , "Iraq", "112"
                , "Ireland", "112"
                , "Isle of Man", "999"
                , "Israel", "100"
                , "Italy", "112"
                , "Jamaica", "119"
                , "Japan", "110"
                , "Jordan", "192"
                , "Kazakhstan", "03"
                , "Kenya", "999"
                , "Kiribati", "192"
                , "Kosovo", "192"
                , "North Korea", "110"
                , "South Korea", "112"
                , "Kuwait", "112"
                , "Kyrgyzstan", "103"
                , "Laos", "1191"
                , "Latvia", "112"
                , "Lebanon", "112"
                , "Lesotho", "123"
                , "Liberia", "911"
                , "Libya", "193"
                , "Liechtenstein", "112"
                , "Lithuania", "112"
                , "Luxembourg", "112"
                , "Macau", "999"
                , "Macedonia", "92"
                , "Madagascar", "117"
                , "Malawi", "997"
                , "Malaysia", "999"
                , "Maldives", "119"
                , "Mali ", "18"
                , "Marianas Island", "911"
                , "Marshall Islands", "625 8666"
                , "Malta", "112"
                , "Martinique", "17"
                , "Mauritania", "117"
                , "Mauritius", "999"
                , "MŽxico", "060"
                , "Micronesia", "911"
                , "Moldova", "902"
                , "Monaco", "112"
                , "Mongolia", "102"
                , "Montenegro", "122"
                , "Montserrat", "999"
                , "Morocco", "19"
                , "Mozambique", "119"
                , "Namibia", "1011"
                , "Nauru", "110"
                , "Nepal", "100"
                , "Netherlands", "112"
                , "Netherlands Antilles", "112"
                , "New Zealand", "111"
                , "Nicaragua", "118"
                , "Niger", "112"
                , "New Zealand", "111"
                , "Nigeria", "112"
                , "Northern Ireland", "112"
                , "Norway", "112"
                , "Oman", "999"
                , "Pakistan", "15"
                , "Palau", "911"
                , "Palestine", "100"
                , "Panama", "104"
                , "Papua New Guinea", "000"
                , "Paraguay", "00"
                , "Peru", "911"
                , "Philippines", "117"
                , "Poland", "112"
                , "Portugal", "112"
                , "Puerto Rico", "911"
                , "Qatar", "999"
                , "RŽunion", "17"
                , "Romania", "112"
                , "Russia", "112"
                , "Rwanda", "999"
                , "Samoa", "999"
                , "San Marino", "112"
                , "Sao Tome and Principe", "112"
                , "Saudi Arabia", "999"
                , "Scotland", "112"
                , "Senegal", "17"
                , "Serbia", "94"
                , "Seychelles", "999"
                , "Sierra Leone", "999"
                , "Singapore", "999"
                , "Slovak Republic", "158"
                , "Slovenia", "112"
                , "Solomon Islands", "911"
                , "Somalia", "888"
                , "South Africa", "10111"
                , "Cape Town", "107"
                , "Spain", "112"
                , "Sri Lanka", "2421052"
                , "St. Helena", "911"
                , "St. Kitts & Nevis", "911"
                , "St. Lucia", "911"
                , "St. Marten", "911"
                , "Sudan", "999"
                , "Suriname", "115"
                , "Swaziland", "999"
                , "Sweden", "112"
                , "Switzerland", "117"
                , "Syria", "112"
                , "French Polynesia", "112"
                , "Taiwan", "110"
                , "Tajikistan", "112"
                , "Tanzania", "112"
                , "Thailand", "191"
                , "Tibet", "110"
                , "Togo", "101"
                , "Tonga", "911"
                , "Trinidad & Tobago", "999"
                , "Tunisia", "197"
                , "Turkey", "100"
                , "Turkmenistan", "03"
                , "Turks and Caicos Islands", "911"
                , "Tuvalu", "911"
                , "Uganda", "112"
                , "Ukraine", "02"
                , "United Arab Emirates", "999"
                , "United Kingdom", "112"
                , "United States", "911"
                , "Uruguay", "911"
                , "US Virgin Islands", "911"
                , "Uzbekistan", "03"
                , "Vanuatu", "112"
                , "Vatican City", "112"
                , "Venezuela", "171"
                , "Vietnam", "03"
                , "Western Sahara", "150"
                , "Western Samoa", "999"
                , "Yemen", "194"
                , "Zambia", "999"
                , "Zimbabwe", "999"};

        Map<String, String> countryNameCode = new HashMap<>();
        int size = country.length;
        int i = 0;
        do {
            countryNameCode.put(country[i], country[i + 1]);
            i = i + 2;
        }
        while (i < size);

        return countryNameCode;
    }

    public static boolean checkLocationPermission(Context context) {
        return ActivityCompat
                .checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED ||
                ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION)
                        == PackageManager.PERMISSION_GRANTED;
    }

    public static void openPdfFile(Context context, String url) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(Uri.parse("http://docs.google.com/viewer?url=" + url), "text/html");
        context.startActivity(intent);
    }

    public static void openUrl(Context context, String url) {
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        context.startActivity(browserIntent);
    }
}
