
package com.sca.in_telligent.ui.splash;


import com.sca.in_telligent.ui.base.MvpView;

public interface SplashMvpView extends MvpView {

    void openLoginActivity();

    void openMainActivity();

    void openIntroActivity();
}
