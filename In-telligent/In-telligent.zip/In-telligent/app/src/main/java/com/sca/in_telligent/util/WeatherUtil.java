package com.sca.in_telligent.util;

public interface WeatherUtil {


  public void handleWeatherAlert(final String weatherAlertId);
}
