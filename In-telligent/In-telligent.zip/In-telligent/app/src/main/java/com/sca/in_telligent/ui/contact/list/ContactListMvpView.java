package com.sca.in_telligent.ui.contact.list;

import com.sca.in_telligent.ui.base.MvpView;

public interface ContactListMvpView extends MvpView {

}
