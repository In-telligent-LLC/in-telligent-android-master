package com.sca.in_telligent.ui.contact.list;

import com.sca.in_telligent.ui.base.MvpPresenter;

public interface ContactListMvpPresenter<V extends ContactListMvpView> extends MvpPresenter<V> {

}
