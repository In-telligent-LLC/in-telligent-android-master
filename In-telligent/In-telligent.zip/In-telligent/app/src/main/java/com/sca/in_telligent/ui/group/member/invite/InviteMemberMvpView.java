package com.sca.in_telligent.ui.group.member.invite;

import com.sca.in_telligent.ui.base.MvpView;

public interface InviteMemberMvpView extends MvpView {
  void inviteResult(boolean success);
}
