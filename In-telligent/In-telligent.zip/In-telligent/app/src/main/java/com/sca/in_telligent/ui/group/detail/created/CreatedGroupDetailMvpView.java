package com.sca.in_telligent.ui.group.detail.created;

import com.sca.in_telligent.ui.base.MvpView;

public interface CreatedGroupDetailMvpView extends MvpView {

  void groupDeleted();
}
