package com.sca.in_telligent.ui.auth.forgot;

import com.sca.in_telligent.ui.base.DialogMvpView;

public interface ForgotPasswordMvpView extends DialogMvpView {

  void showSubmitToast();

}
