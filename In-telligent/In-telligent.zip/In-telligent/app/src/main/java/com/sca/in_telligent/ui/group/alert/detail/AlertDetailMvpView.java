package com.sca.in_telligent.ui.group.alert.detail;

import com.sca.in_telligent.ui.base.MvpView;

public interface AlertDetailMvpView extends MvpView {

}
