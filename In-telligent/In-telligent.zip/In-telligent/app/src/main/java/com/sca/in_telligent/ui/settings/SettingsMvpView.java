package com.sca.in_telligent.ui.settings;

import com.sca.in_telligent.ui.base.MvpView;

public interface SettingsMvpView extends MvpView {
  void gotoLogin();
}
