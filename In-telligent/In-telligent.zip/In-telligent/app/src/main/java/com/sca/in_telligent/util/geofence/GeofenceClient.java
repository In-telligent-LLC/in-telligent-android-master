package com.sca.in_telligent.util.geofence;

public interface GeofenceClient {

   void populateIntelligentFences(boolean useCache);
}
