package com.sca.in_telligent.ui.base;

public interface DialogMvpView extends MvpView {

  void dismissDialog(String tag);
}