package com.sca.in_telligent.util;

import io.reactivex.Observable;
import java.io.File;

public interface VideoDownloader {

  Observable<File> download(String url, String filename);
}
