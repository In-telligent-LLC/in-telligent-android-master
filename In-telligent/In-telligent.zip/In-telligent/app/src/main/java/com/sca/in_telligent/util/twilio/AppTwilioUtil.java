package com.sca.in_telligent.util.twilio;

import android.content.Context;
import android.util.Log;

import com.sca.in_telligent.data.DataManager;
import com.sca.in_telligent.openapi.data.network.model.VoipCallRequest;
import com.sca.in_telligent.data.prefs.PreferencesHelper;
import com.sca.in_telligent.di.ApplicationContext;
import com.sca.in_telligent.util.Responder;
import com.sca.in_telligent.util.rx.SchedulerProvider;
import com.twilio.voice.Call;
import com.twilio.voice.CallException;
import com.twilio.voice.Voice;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import javax.inject.Inject;
import javax.inject.Singleton;

import io.reactivex.disposables.CompositeDisposable;

@Singleton
public class AppTwilioUtil implements TwilioUtil {

  private static String TAG = AppTwilioUtil.class.getSimpleName();

  private boolean isOutgoing;

  private String conferenceId = "";

  private String remoteUserName;
  private String uuid;
  private Context mContext;
  private String subscriberId;

  private Call twilioCall;

  private final DataManager mDataManager;
  private final SchedulerProvider mSchedulerProvider;
  private final CompositeDisposable mCompositeDisposable;
  private final PreferencesHelper mPreferencesHelper;
  private final Responder mResponder;


  private TwilioUtilListener listener;

  @Inject
  public AppTwilioUtil(@ApplicationContext Context context, DataManager dataManager,
      SchedulerProvider schedulerProvider,
      CompositeDisposable compositeDisposable, Responder responder,
      PreferencesHelper preferencesHelper) {
    mContext = context;
    mDataManager = dataManager;
    mSchedulerProvider = schedulerProvider;
    mCompositeDisposable = compositeDisposable;
    mResponder = responder;
    mPreferencesHelper = preferencesHelper;
  }

  private String randomConferenceId() {
    String letters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    int lettersLength = letters.length();

    Random generator = new Random();
    StringBuilder randomStringBuilder = new StringBuilder();
    for (int i = 0; i < 50; i++) {
      randomStringBuilder.append(letters.charAt(generator.nextInt(lettersLength)));
    }
    return randomStringBuilder.toString();
  }

  @Override
  public void makeCall(String buildingId) {

    if (conferenceId.isEmpty()) {
      conferenceId = randomConferenceId();
    }

    subscriberId = mPreferencesHelper.getSubscriberId();

    mCompositeDisposable.add(mDataManager.getVoipToken().subscribeOn(mSchedulerProvider.io())
            .observeOn(mSchedulerProvider.ui()).subscribe(
                    voipTokenResponse -> {
                      if (voipTokenResponse.getToken() != null & !voipTokenResponse.getToken()
                              .isEmpty()) {

                        Map<String, String> params = new HashMap<>();
                        params.put("buildingId", buildingId);
                        params.put("isCM", "");
                        params.put("conferenceId", conferenceId);

                        twilioCall = Voice
                                .call(mContext, voipTokenResponse.getToken(), params,
                                        getListener());

                        VoipCallRequest voipCallRequest = new VoipCallRequest();
                        voipCallRequest.setBuildingId(buildingId);
                        voipCallRequest.setConferenceId(conferenceId);
                        voipCallRequest.setSenderId(Integer.parseInt(subscriberId));

                        mCompositeDisposable.add(mDataManager.makeVoipCall(voipCallRequest)
                                .subscribeOn(mSchedulerProvider.io())
                                .observeOn(mSchedulerProvider.ui()).
                                        subscribe(voipCallResponse -> {
                                          if (voipCallResponse.isAccepted()) {
                                            callWasAnswered();
                                          } else {
                                            failCall();
                                          }
                                        }, throwable -> {
                                          failCall();
                                        }));

                      }
                    }, throwable -> {
                      Log.e(TAG, "There was an error trying to perform the call", throwable);
                      failCall();
                    }));
  }

  @Override
  public void answerCall() {
    String token = "";
    Map<String, String> params = new HashMap<>();
    params.put("isCM", "true");
    params.put("conferenceId", conferenceId);

    twilioCall = Voice
        .call(mContext, token, params, getListener());

    HashMap<String, Object> map = new HashMap<>();

    map.put("accepted", true);

    mResponder.respond(uuid, map);
  }

  @Override
  public void rejectCall() {

    if (twilioCall == null) {
      return;
    }

    HashMap<String, Object> map = new HashMap<>();
    map.put("accepted", false);

    mResponder.respond(uuid, map);

    twilioCall = null;
  }

  @Override
  public void failCall() {
    if (listener != null) {
      listener.callDidFail();
    }
  }

  @Override
  public void callWasAnswered() {
    if (listener != null) {
      listener.callDidStart();
    }
  }

  @Override
  public void setListener(TwilioUtilListener listener) {
    this.listener = listener;
  }

  @Override
  public void endCall() {
    if (twilioCall != null) {
      twilioCall.disconnect();
    }
    twilioCall = null;
  }

  @Override
  public void fillFields(String subscriberId, String uuid,
      String remoteUsername, String conferenceId) {
    this.subscriberId = subscriberId;
    this.uuid = uuid;
    this.remoteUserName = remoteUsername;
    this.conferenceId = conferenceId;
  }


  public Call.Listener getListener() {
    return new Call.Listener() {

      @Override
      public void onConnectFailure(Call call, CallException e) {

      }

      @Override
      public void onConnected(Call call) {
        if (listener != null) {
          listener.callDidProgress(call);
        }
      }

      @Override
      public void onDisconnected(Call call, CallException e) {
        if (listener != null) {
          listener.callDidEnd();
        }
      }
    };
  }

  public interface TwilioUtilListener {

    void callDidFail();

    void callDidProgress(Call call);

    void callDidStart();

    void callDidEnd();

  }
}
