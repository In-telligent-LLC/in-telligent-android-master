package com.sca.in_telligent.util.video;

/**
 * Created by zacharyzeno on 8/15/16.
 */
public interface ProgressReporter {

    void onProgress(int progress);

}
